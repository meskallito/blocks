# MANUAL: run nvim and execute :call minpac#update()
#install node for coc
npm install -g neovim
pyenv install 3.12.1
pyenv global 3.12.1
pyenv rehash

#from https://github.com/joshdick/onedark.vim
git clone https://github.com/joshdick/onedark.vim.git  ~/.vim/pack/onedark/opt/onedark.vim
# Install minpac
git clone https://github.com/k-takata/minpac.git ~/.config/nvim/pack/minpac/opt/minpac
# Install plugins in neovim
:call minpac#update()

# Old problems with onedark.vim don't exist anymore
#cp -r ~/.config/nvim/pack/minpac/start/onedark.vim/autoload/* ~/.config/nvim/pack/minpac/opt/minpac/autoload/
#cp -r ~/.config/nvim/pack/minpac/start/onedark.vim/colors/onedark.vim ~/.config/nvim/colors
#cp -r ~/.config/nvim/pack/minpac/start/onedark.vim/autoload/* ~/.config/nvim/autoload

# build coc.nvim
#cd ~/.config/nvim/pack/minpac/start/coc.nvim
#npm install
#npm run build



# OPTIONAL: Language servers for coc.nvim
# from https://github.com/neoclide/coc.nvim
# language servers
# brew install hashicorp/tap/terraform-ls
# npm install -g dockerfile-language-server-nodejs
# npm i -g bash-language-server
# gem install solargraph

# Language servers
# :CocInstall coc-json
# For scala
# :CocInstall coc-metals
# For typescript and javascript
# :CocInstall coc-tsserver
# For Ruby
# :CocInstall coc-solargraph
# For Python
# :CocInstall coc-pyright
# For Markdown
# :CocInstall coc-markdownlint
