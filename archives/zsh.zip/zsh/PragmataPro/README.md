# Pragmata Pro font

It's the 0.829 version of the font. I keep it here for my dotfiles.
